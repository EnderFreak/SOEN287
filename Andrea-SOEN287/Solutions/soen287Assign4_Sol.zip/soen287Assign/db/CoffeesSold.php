<$php
$boys= array( '1' => 'Abe', '2' => 'Bob', '3' => 'Charles');
echo "Array as it is:<br />");
print_r($boys);
echo ("<br /><br />");