<!DOCTYPE html">
 
<html lang="en">
<head>
<title>Simple Form - Favorite Animal</title>
</head>
 
<body>
<h2>Favorite Animal</h2>
 
<form method="post" action="response.php">
Please enter your favorite animal:  <br />
<input type="text" name="animal" />
<p />
<input type="submit" name="submit" value="Go" />
</form>
 
</body>
</html>