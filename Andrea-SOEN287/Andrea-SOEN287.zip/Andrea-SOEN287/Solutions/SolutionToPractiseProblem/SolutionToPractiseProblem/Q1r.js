//Register events
document.getElementById("apples").onchange = applesFcn;
document.getElementById("oranges").onchange = orangesFcn;
document.getElementById("bananas").onchange = bananasFcn;
document.getElementById("submit").onclick = finish;